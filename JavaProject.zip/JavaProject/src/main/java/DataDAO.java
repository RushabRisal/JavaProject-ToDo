import java.sql.*;

public class DataDAO {
	public Connection Connect()throws Exception{
		String url="jdbc:mysql://localhost:3306/todoproj";
		String uname="root";
		String password="";
		Class.forName("com.mysql.cj.jdbc.Driver");
		Connection cn=DriverManager.getConnection(url,uname,password);
		return cn;
	}
	public boolean insert(Data data)throws Exception{
		Connection cn=Connect();
		PreparedStatement st=cn.prepareStatement("INSERT INTO info(date_info,title,subject)values(?,?,?)");
		st.setString(1, data.get_Date());
		st.setString(2,data.get_Title());
		st.setString(3, data.get_Sub());
		int s=st.executeUpdate();
		if(s>0) {
			return true;
		}
		else {
			return false;
		}
	}
	
	
}
