

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;

@WebServlet("/adminlogin")
public class adminlogin extends HttpServlet {

	protected void service(HttpServletRequest req, HttpServletResponse res) 
			throws ServletException, IOException {
		String uname=req.getParameter("username");
		String pwd=req.getParameter("password");
		if(uname.equals("admin") && pwd.equals("admin@123")) {
			HttpSession ssa=req.getSession();
			ssa.setAttribute("user",uname);
			RequestDispatcher rd=req.getRequestDispatcher("/profile");
			rd.forward(req,res);
		}
		else {
			res.getWriter().print("unable to login");
			RequestDispatcher rd=req.getRequestDispatcher("Login.jsp");
			rd.include(req, res);
		}
	}

}
