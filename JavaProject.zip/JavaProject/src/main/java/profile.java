
import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;

import jakarta.servlet.http.HttpSession;

@WebServlet("/profile")
public class profile extends HttpServlet {
	public void service(HttpServletRequest req,HttpServletResponse res)
			throws IOException, ServletException{
		HttpSession ssa=req.getSession(false);
		if(ssa==null) {
			RequestDispatcher rd=req.getRequestDispatcher("Login.jsp");
			rd.forward(req, res);
		}
		PrintWriter out=res.getWriter();
		if(ssa!=null) {
//			String ssaName=(String)ssa.getAttribute("user");
//			out.print("hello"+ssaName);
			RequestDispatcher rd=req.getRequestDispatcher("dashboard.jsp");
			rd.forward(req,res);
		}
		else {
			out.print("not logged in");
			RequestDispatcher rd=req.getRequestDispatcher("Login.jsp");
			rd.include(req, res);
		}
	}

}
