

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;

/**
 * Servlet implementation class medium
 
 */


import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;

/**
 * Servlet implementation class medium
 
 */
@WebServlet("/medium")
public class medium extends HttpServlet {
	protected void doPost(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		// TODO Auto-generated method stub
		PrintWriter out=res.getWriter();
	
		try {
			
			String date=(String)req.getParameter("date");
			String title=req.getParameter("title");
			String sub=req.getParameter("subject");
			Data data=new Data();
			data.set_Date(date);
			data.set_Title(title);
			data.set_Sub(sub);
			DataDAO dbase=new DataDAO();
			boolean s=dbase.insert(data);
			if(s) {
				RequestDispatcher rd=req.getRequestDispatcher("/dashboard.jsp");
				rd.forward(req,res);
			}
			else {
				out.println("<h1>something wrong</h1>");
				RequestDispatcher rd=req.getRequestDispatcher("/dashboard.jsp");
				rd.include(req, res);
			}
			
		}catch(Exception e) {
			out.println(e.getMessage());
		}
		}
		
	}


