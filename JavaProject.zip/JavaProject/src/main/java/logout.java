 

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;


public class logout extends HttpServlet {
	public void service(HttpServletRequest req,HttpServletResponse res)
			throws IOException,ServletException{
		HttpSession ssa= req.getSession();
		ssa.invalidate();
		RequestDispatcher rd=req.getRequestDispatcher("Login.jsp");
		rd.forward(req, res);
	}
}
