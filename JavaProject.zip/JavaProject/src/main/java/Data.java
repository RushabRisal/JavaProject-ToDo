

class Data{
	String Date,Title,Sub;
	public void set_Date(String Date)
	{
		this.Date=Date;
	}
	public void set_Title(String Title ) {
		this.Title=Title;
	}
	public void set_Sub(String Sub) {
		this.Sub=Sub;
	}
	public String get_Date() {
		return Date;
	}
	public String get_Title() {
		return Title;
	}
	public String get_Sub() {
		return Sub;
	}
}